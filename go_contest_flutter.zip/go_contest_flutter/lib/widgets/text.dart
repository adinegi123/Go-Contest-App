// import 'package:flutter/material.dart';
//
// Widget reusableSmallText(context, text) {
//   return Text(
//     text,
//     style: Theme.of(context).textTheme.title,
//   );
// }
