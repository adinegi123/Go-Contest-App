import 'package:flutter/material.dart';

class ColorConst {
  // static Color buttonColor = const Color(0xff2E0467);
  static Color buttonColor = const Color(0xff5A4FCF);
  static Color primaryTextColor = const Color(0xff3A1273);
  // static Color primaryTextColor = const Color(0xff541B54);
  static Color lightblack = const Color(0xff454545);
// static Color buttonColor = const Color(0xff8f10de);
}
