import 'package:flutter/material.dart';

class Sharepage extends StatefulWidget {
  const Sharepage({Key? key}) : super(key: key);

  @override
  State<Sharepage> createState() => _SharepageState();
}

class _SharepageState extends State<Sharepage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
