class OnBoardModelData {
  late String imgUrl;
  late String title;
  late String subtitle;

  OnBoardModelData(
      {required this.imgUrl, required this.title, required this.subtitle});
}
